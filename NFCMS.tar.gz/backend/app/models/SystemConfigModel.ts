import { F } from "dyapi/core/datafield.js";
import { Model } from "dyapi/core/model.js";
import { Inject } from "dyapi/utils/decorators.js";
import { Locked } from "dyapi/utils/lock.js";
import { BadRequestError} from "dyapi/utils/error.js";
import testContainer from "../containers/testContainer.js";

// Removed @CRUD("systemconfig") so it's fully managed via SystemController
export default class SystemConfigModel extends Model {
    @Inject(testContainer) declare container;
    tablename = "system_config";
    datafields = [
        F.String("key").unique().notNull(),
        F.String("value"),
    ];
    permission = { // Internal model now, API not exposed directly
        "PUBLIC": "RO",
        "DEFAULT": "R",
        "super_admin": "C,R,U,D",
    };

    async GetConfig() {
        return Locked("system_config_cache", async () => {
            if (globalConfigCache == null) {
                globalConfigCache = {};
                const allConfig = await this.read({});
                for (const item of allConfig) {
                    if (item.key in VALID_CONFIG_KEYS) {
                        globalConfigCache[item.key] = item.value;
                    }
                }
                for (const key in VALID_CONFIG_KEYS) {
                    if (globalConfigCache[key] === undefined) {
                        globalConfigCache[key] = VALID_CONFIG_KEYS[key];
                    }
                }
            }
            return globalConfigCache;
        })
    }

    async SetConfig(key: string, value: string) {
        if(!(key in VALID_CONFIG_KEYS)){
            throw new BadRequestError(`Invalid config key: ${key}`);
        }
        const configCache = await this.GetConfig();
        if(value === configCache[key]){
            return;
        }
        const item = await this.read({ filter: { key } });
        if (item.length === 0) {
            await this.create({ key, value });
        }else{
            await this.update({ filter:{ key } }, { value });
        }
        globalConfigCache![key] = value;
    }

    ClearCache() {
        globalConfigCache = null;
    }
}
export const VALID_CONFIG_KEYS = {
    "is_initialized" : "false",
    "site_name" : "NFCMS",
    "subtitle": "",
    "icp_record": "",
    "mourning_mode": "0",
    "home_template": "DefaultHome",
    // Storage config (JSON: { provider, local: {...}, s3: {...}, tencent_cos: {...} })
    "storage_config": '{"provider": "local", "local": {"upload_dir": "static/uploads"}}',
};
export let globalConfigCache: Record<string, string> | null = null;
