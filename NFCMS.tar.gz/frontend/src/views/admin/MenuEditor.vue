<template>
  <AdminModal :title="isEditing ? $t('action.edit') : $t('action.new')" widthClass="max-w-4xl" @close="emit('close')" @save="save" :disableSave="!formData.name">
    <div class="space-y-6">
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-[14px] font-medium text-[rgba(0,0,0,0.8)] mb-1">{{ $t('form.name') }} <span class="text-red-500">*</span></label>
          <InputText unstyled v-model="formData.name" class="w-full h-10 px-3 border border-[rgba(0,0,0,0.15)] rounded-[8px] focus:outline-none focus:border-apple-blue focus:ring-1 focus:ring-apple-blue transition-shadow bg-white text-[14px]"/>
        </div>
        <div>
          <label class="block text-[14px] font-medium text-[rgba(0,0,0,0.8)] mb-1">{{ $t('form.locationKey') || 'Key Location (e.g. "header")' }}</label>
          <InputText unstyled v-model="formData.location" class="w-full h-10 px-3 border border-[rgba(0,0,0,0.15)] rounded-[8px] focus:outline-none focus:border-apple-blue focus:ring-1 focus:ring-apple-blue transition-shadow bg-white text-[14px]"/>
        </div>
      </div>

      <div class="bg-[#fafafc] border border-[rgba(0,0,0,0.05)] rounded-[8px] p-4 flex items-center justify-between">
          <div>
              <h3 class="text-[14px] font-semibold text-[rgba(0,0,0,0.8)] mb-1">{{ $t('form.generateRecursively') || 'Generate from Category' }}</h3>
              <p class="text-[12px] text-[rgba(0,0,0,0.5)]">{{ $t('form.generateDesc') || 'Automatically fetch subcategories to build nested menu.' }}</p>
          </div>
          <div class="flex gap-2 items-center">
              <Select v-model="selectedCategoryForGenerate" :options="categoryOptions" optionLabel="label" optionValue="value" unstyled :pt="{ root: 'h-10 px-3 border border-[rgba(0,0,0,0.15)] rounded-[8px] focus:outline-none focus:border-apple-blue focus:ring-1 focus:ring-apple-blue transition-shadow bg-white flex items-center justify-between cursor-pointer relative min-w-[200px]', label: 'text-[14px] text-[rgba(0,0,0,0.8)] truncate', dropdown: 'w-4 h-4 opacity-50 absolute right-3 top-1/2 -translate-y-1/2', overlay: 'bg-white border border-[rgba(0,0,0,0.15)] rounded-[8px] shadow-lg mt-1 py-1 z-[9999]', option: ({ context }: any) => ({ class: ['px-3 py-2 text-[14px] cursor-pointer hover:bg-[#f5f5f7]', context.selected ? 'bg-apple-blue text-white hover:bg-apple-blue' : 'text-[rgba(0,0,0,0.8)]'] }) }" />
              <Button unstyled type="button" @click="generateFromCategory" :disabled="!selectedCategoryForGenerate" class="h-10 px-4 bg-apple-blue text-white rounded-[8px] text-[14px] hover:bg-[#2997ff] disabled:opacity-50 transition-colors focus:outline-none font-medium flex items-center justify-center">{{ $t('action.generate') || 'Generate' }}</Button>
          </div>
      </div>

      <div>
          <div class="flex justify-between items-center mb-3">
            <label class="block text-[14px] font-medium text-[rgba(0,0,0,0.8)]">{{ $t('form.menuItems') || 'Menu Items (Tree)' }}</label>
            <Button unstyled @click="addItem(formData.items)" type="button" class="text-[13px] font-medium text-apple-blue whitespace-nowrap px-3 py-2 bg-[#e0f2fe] hover:bg-[#bae6fd] rounded-[8px] focus:outline-none transition-colors">+ {{ $t('action.addRootItem') || 'Add Root Item' }}</Button>
          </div>
          <div class="bg-[#f5f5f7] border border-[rgba(0,0,0,0.05)] rounded-[12px] p-4 min-h-[200px]">
            <MenuItemEditor v-if="formData.items && formData.items.length" :items="formData.items" :categories="categories" :articles="articles" @update="formData.items = $event" />
            <div v-else class="text-center text-[rgba(0,0,0,0.4)] py-12 text-[14px]">{{ $t('system.noEntries') || 'No items added.' }}</div>
          </div>
      </div>
    </div>
  </AdminModal>
</template>

<script setup lang="ts">
import { ref, watch, onMounted, computed } from 'vue';
import { useI18n } from 'vue-i18n';
import AdminModal from '../../components/AdminModal.vue';
import InputText from 'primevue/inputtext';
import Button from 'primevue/button';
import Select from 'primevue/select';
import { crudAPI } from '../../api';
import MenuItemEditor from './MenuItemEditor.vue';

const { t } = useI18n();

const props = defineProps<{ initialData: any, isEditing: boolean }>();
const emit = defineEmits(['close', 'save']);

const formData = ref<any>({ name: '', location: '', items: [] });
const categories = ref<any[]>([]);
const articles = ref<any[]>([]);
const selectedCategoryForGenerate = ref<number | null>(null);

const categoryOptions = computed(() => {
    const opts = [{ label: t('form.selectCategory') || 'Select Category', value: null }];
    categories.value.forEach((c: any) => opts.push({ label: c.name, value: c.id }));
    return opts;
});

onMounted(async () => {
    try {
        const catRes: any = await crudAPI.getList('categories');
        const artRes: any = await crudAPI.getList('articles');
        categories.value = catRes.data || catRes || [];
        articles.value = artRes.data || artRes || [];
    } catch(e) {}
});

watch(() => props.initialData, (newVal) => {
    formData.value = JSON.parse(JSON.stringify(newVal));
    if (!formData.value.items) formData.value.items = [];
}, { immediate: true, deep: true });

const addItem = (arr: any[]) => {
    arr.push({ label: 'New Item', url: '/', type: 'custom', refId: null, children: [] });
};

const buildMenuTree = (parentId: number | null): any[] => {
    return categories.value
        .filter(c => c.parent_id === parentId)
        .sort((a, b) => (a.weight) - (b.weight))
        .map(c => {
            return {
                label: c.name,
                url: `/a/${c.slug}`,
                type: 'category',
                refId: c.id,
                children: buildMenuTree(c.id)
            };
        });
};

const generateFromCategory = () => {
    if (!selectedCategoryForGenerate.value) return;
    const newItems = buildMenuTree(selectedCategoryForGenerate.value);
    if (!formData.value.items) formData.value.items = [];
    formData.value.items.push(...newItems);
    selectedCategoryForGenerate.value = null; // reset
};

const save = () => {
    emit('save', formData.value);
};
</script>
